﻿using InnovationDaysLibrary;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace InnovationDaysWebConsumer
{
    class Program
    {

        static HttpClient client = new HttpClient();
        static Project t = new Project();
        static string uri = "https://localhost:44360/Projects";
        static void Main(string[] args)
        {
            try
            {
                RunAsync();
                Console.ReadKey();
            }
            catch (Exception ex)
            {



            }
        }

        static async void RunAsync()
        {
            client.BaseAddress = new Uri(uri);
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            // Get all data from resources 
            IList<Project> getAllList = await GetAllProjectsAsync();
            ShowObjectData(getAllList);
            Console.WriteLine("Get By Id ...............................");
            var getAllListById = await GetAllProjectById(1);
            ShowSingleObjectData(getAllListById);
            Console.WriteLine("Add New Resource ...............................");
            Project newProject = new Project() { ID=10, Category="Math", Name = "Math Project", Point= 80 };
            var newResource = await AddNewProject(newProject);
            ShowSingleObjectData(newResource);

        }

        static async Task<IList<Project>> GetAllProjectsAsync() // why async: to be performed intependant on other tasks. 
                                                            //it wont wait for other tasks to be done they can all run at the same time 
        {
            using (HttpClient client = new HttpClient())
            {
                string jsonContent = await client.GetStringAsync(uri);
                IList<Project> cust = JsonConvert.DeserializeObject<IList<Project>>(jsonContent);
                return cust;
            }
        }


        static async Task<Project> GetAllProjectById(int id)
        {
            string uriId = uri + "/" + id;
            HttpResponseMessage response = await client.GetAsync(uriId);
            if (response.StatusCode != HttpStatusCode.NotFound)
            {
                response.EnsureSuccessStatusCode();
                string jsonContent = await response.Content.ReadAsStringAsync(); // the data comes here in Json format
                var singleObj = JsonConvert.DeserializeObject<Project>(jsonContent);// here we deserialze it 
                return singleObj; // and it will return the desirialized object 
            }
            else
            {
                throw new Exception("Trade Id is not found");
            }
        }

        static async Task<Project> AddNewProject(Project newProject)
        {
            var jsonContent = JsonConvert.SerializeObject(newProject);
            StringContent content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            HttpResponseMessage response = await client.PostAsync(uri, content);
            if (response.StatusCode != HttpStatusCode.Conflict)
            {
                response.EnsureSuccessStatusCode();
                string jsonString = await response.Content.ReadAsStringAsync();
                var newlyCreatedResource = JsonConvert.DeserializeObject<Project>(jsonString);
                return newlyCreatedResource;
            }
            else
            {
                throw new Exception("Trade already exist, try anther Id");
            }
        }

        static void ShowObjectData(IList<Project> list)
        {
            foreach (var i in list)
            {
                Console.WriteLine(i.ID + "," + i.Category + "," + i.Name + "," + i.Point);
            }
        }
        static void ShowSingleObjectData(Project i)
        {
            Console.WriteLine(i.ID + "," + i.Category + "," + i.Name + "," + i.Point);
        }

    }
}
