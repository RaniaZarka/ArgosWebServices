﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InnovationDaysLibrary;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace InnovationsDaysWebApi.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ProjectsController : ControllerBase
    {

        public static List<Project> projectList= new List<Project>()
            {
            new Project(1, "My Project", "Science", 70),
            new Project(2,"Good Project", "Programming", 80),
            new Project(3, "Best Project", "Physics", 85)

            };
        // GET: Projects
        [HttpGet]
        public IEnumerable <Project> Get()
        {
            return projectList;
        }

        // GET: Projects/5
        [HttpGet("{id}", Name = "Get")]
        public IActionResult Get(int id)
        {
            var project = GetProject(id);
            if (project != null)
            {
                return Ok(project);
            }
            else
            {
                return NotFound(new { message = " ID does not exist" });
            }
        }

        // POST: Projects
        [HttpPost]
        public IActionResult Post([FromBody] Project value)
        {
            Project p = GetProject(value.ID);
            if(p!= null)
            {
                return Conflict(new { message = "Id already exists" });
            }


            projectList.Add(value);
            return CreatedAtAction("Get", new { id = GetId() }, value);
        }

        // PUT: api/Projects/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

        public Project GetProject(int id)
        {
            var p = projectList.FirstOrDefault(e => e.ID == id);
            return p;
        }
        int GetId()
        {
            int max = projectList.Max(x => x.ID);
            return max + 1;
        }
    }
}
