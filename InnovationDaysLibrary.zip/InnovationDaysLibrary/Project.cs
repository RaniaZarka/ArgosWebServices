﻿using System;

namespace InnovationDaysLibrary
{
    public class Project
    {
        private string name;
        private int point;

        public Project()
        {
        }

        public Project(int id, string name, string category, int point)
            {
            ID = id;
            Name = name;
            Category = category;
            Point = point;
            }
      //  public Project() { }

        public int ID { get; set; }
        public string Name 
        {
            get
            {
                return name;
            }
            set
            {
                if (String.IsNullOrEmpty(value) || value.Length < 5)
                    throw new ArgumentException("Name should be at least 4 characters");
                else
                    name = value;
            }
        }

        public string Category { get; set; }

        public int Point
        {
            get
            {
                return point;
            }
            set 
            {
                if (value < 1 || value > 100)
                    throw new ArgumentOutOfRangeException("outside of the range ");
                else
                    point = value;
            }
        }


      
    }

}
