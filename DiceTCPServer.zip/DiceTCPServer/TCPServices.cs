﻿using DiceLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Text.Json;
using DiceTCPServer;

namespace DiceTCPServer
{
   public  class TCPServices
    {
       
            }
        }
    
    

