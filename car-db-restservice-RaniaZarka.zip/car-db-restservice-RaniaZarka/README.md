# WebApiCar
Simpel Rest webapi som gemmer data om biler i en statisk list. webservicen bruges som backend, i et typescript program. 
## Swagger / Open Api
Web Api'et understøtter nu swagger OPENAPI
Det er muligt at se swagger dokumentationen via http://localhost:54180/index.html

Alle summaries på metoderne i webapi'et bliver brugt i swagger dokumentationen 

## Guide til at opsætning af swagger i .Netcore
https://docs.microsoft.com/en-us/aspnet/core/tutorials/getting-started-with-swashbuckle?view=aspnetcore-2.2&tabs=visual-studio

